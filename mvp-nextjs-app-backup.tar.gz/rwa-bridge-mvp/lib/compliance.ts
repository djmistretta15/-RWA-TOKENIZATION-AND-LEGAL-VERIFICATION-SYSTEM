import { KYCStatus, AccreditationStatus } from '@prisma/client'

export interface ComplianceCheck {
  allowed: boolean
  reason?: string
  warnings?: string[]
}

export function checkTransferCompliance(params: {
  fromKycStatus: KYCStatus
  toKycStatus: KYCStatus
  fromAccreditation: AccreditationStatus
  toAccreditation: AccreditationStatus
  amount: number
}): ComplianceCheck {
  const { fromKycStatus, toKycStatus, fromAccreditation, toAccreditation, amount } = params

  // Check sender KYC
  if (fromKycStatus !== 'VERIFIED') {
    return {
      allowed: false,
      reason: 'Sender KYC verification required',
    }
  }

  // Check receiver KYC
  if (toKycStatus !== 'VERIFIED') {
    return {
      allowed: false,
      reason: 'Recipient KYC verification required',
    }
  }

  const warnings: string[] = []

  // Check accreditation for large transfers
  if (amount > 100000) {
    if (fromAccreditation === 'NOT_ACCREDITED' || toAccreditation === 'NOT_ACCREDITED') {
      return {
        allowed: false,
        reason: 'Transfers over $100,000 require accredited investor status',
      }
    }
  }

  // Warning for large institutional transfers
  if (amount > 1000000) {
    warnings.push('Large transfer detected - additional monitoring recommended')
  }

  return {
    allowed: true,
    warnings: warnings.length > 0 ? warnings : undefined,
  }
}

export function checkRedemptionEligibility(params: {
  balance: number
  requestAmount: number
  kycStatus: KYCStatus
  assetStatus: string
}): ComplianceCheck {
  const { balance, requestAmount, kycStatus, assetStatus } = params

  if (kycStatus !== 'VERIFIED') {
    return {
      allowed: false,
      reason: 'KYC verification required for redemptions',
    }
  }

  if (assetStatus === 'FROZEN') {
    return {
      allowed: false,
      reason: 'Asset is currently frozen',
    }
  }

  if (requestAmount > balance) {
    return {
      allowed: false,
      reason: 'Insufficient balance for redemption',
    }
  }

  const warnings: string[] = []

  // Warning for large redemptions
  if (requestAmount > balance * 0.5) {
    warnings.push('Redeeming more than 50% of holdings')
  }

  return {
    allowed: true,
    warnings: warnings.length > 0 ? warnings : undefined,
  }
}

export function getKYCStatusLabel(status: KYCStatus): string {
  const labels: Record<KYCStatus, string> = {
    PENDING: 'Pending Verification',
    VERIFIED: 'Verified',
    REJECTED: 'Rejected',
    EXPIRED: 'Expired',
  }
  return labels[status]
}

export function getAccreditationLabel(status: AccreditationStatus): string {
  const labels: Record<AccreditationStatus, string> = {
    NOT_ACCREDITED: 'Not Accredited',
    ACCREDITED_INVESTOR: 'Accredited Investor',
    QUALIFIED_PURCHASER: 'Qualified Purchaser',
    INSTITUTIONAL: 'Institutional',
  }
  return labels[status]
}

export function calculateMinimumHoldingPeriod(assetType: string): number {
  // Return days
  const periods: Record<string, number> = {
    REAL_ESTATE: 365, // 1 year
    PRIVATE_EQUITY: 730, // 2 years
    BOND: 180, // 6 months
    ART: 180, // 6 months
    COMMODITY: 90, // 3 months
    OTHER: 90,
  }
  return periods[assetType] || 90
}
