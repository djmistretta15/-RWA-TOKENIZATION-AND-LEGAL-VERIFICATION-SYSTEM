import Link from 'next/link'
import { prisma } from '@/lib/db'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { AssetCard } from '@/components/asset-card'
import { formatCurrency, formatTokenAmount } from '@/lib/utils'
import { Building2, TrendingUp, FileText, ArrowRight } from 'lucide-react'

export const dynamic = 'force-dynamic'

export default async function DashboardPage() {
  // Get demo user
  const demoUser = await prisma.user.findUnique({
    where: { email: 'demo@rwabridge.io' },
  })

  if (!demoUser) {
    return <div>User not found. Please run: npm run prisma:seed</div>
  }

  // Get user's assets
  const userAssets = await prisma.assetOwnership.findMany({
    where: { userId: demoUser.id },
    include: {
      asset: true,
    },
  })

  // Get recent transfers
  const recentTransfers = await prisma.transfer.findMany({
    where: { fromUserId: demoUser.id },
    include: {
      asset: true,
    },
    orderBy: { createdAt: 'desc' },
    take: 5,
  })

  // Get pending redemptions
  const pendingRedemptions = await prisma.redemptionRequest.findMany({
    where: {
      userId: demoUser.id,
      status: 'PENDING',
    },
  })

  // Calculate total portfolio value
  const totalPortfolioValue = userAssets.reduce((sum, ownership) => {
    const assetValue = parseFloat(ownership.asset.totalValue.toString())
    const totalSupply = parseFloat(ownership.asset.totalSupply.toString())
    const userBalance = parseFloat(ownership.balance.toString())
    const userValue = (assetValue / totalSupply) * userBalance
    return sum + userValue
  }, 0)

  return (
    <div className="container mx-auto px-4 py-8 space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-4xl font-bold">Dashboard</h1>
        <p className="text-muted-foreground mt-2">
          Welcome back, {demoUser.name}
        </p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              Total Portfolio Value
            </CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(totalPortfolioValue)}</div>
            <p className="text-xs text-muted-foreground mt-1">
              Across {userAssets.length} assets
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              Active Assets
            </CardTitle>
            <Building2 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{userAssets.length}</div>
            <p className="text-xs text-muted-foreground mt-1">
              {userAssets.filter(a => a.asset.status === 'ACTIVE').length} active
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              Pending Redemptions
            </CardTitle>
            <FileText className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{pendingRedemptions.length}</div>
            <p className="text-xs text-muted-foreground mt-1">
              Awaiting approval
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Your Assets */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold">Your Assets</h2>
            <p className="text-muted-foreground">
              Real-world assets you own tokens for
            </p>
          </div>
          <Link href="/assets">
            <Button variant="outline">
              View All <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {userAssets.slice(0, 3).map((ownership) => (
            <AssetCard
              key={ownership.id}
              id={ownership.asset.id}
              name={ownership.asset.name}
              tokenSymbol={ownership.asset.tokenSymbol}
              assetType={ownership.asset.assetType}
              status={ownership.asset.status}
              totalValue={ownership.asset.totalValue.toString()}
              userBalance={ownership.balance.toString()}
              jurisdiction={ownership.asset.jurisdiction}
              oracleConsensus={ownership.asset.oracleConsensus}
            />
          ))}
        </div>
      </div>

      {/* Recent Activity */}
      <div className="space-y-4">
        <div>
          <h2 className="text-2xl font-bold">Recent Activity</h2>
          <p className="text-muted-foreground">
            Your latest transactions and transfers
          </p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Recent Transfers</CardTitle>
            <CardDescription>Latest token movements</CardDescription>
          </CardHeader>
          <CardContent>
            {recentTransfers.length === 0 ? (
              <p className="text-sm text-muted-foreground">No recent transfers</p>
            ) : (
              <div className="space-y-4">
                {recentTransfers.map((transfer) => (
                  <div key={transfer.id} className="flex items-center justify-between py-2 border-b last:border-0">
                    <div>
                      <div className="font-medium">{transfer.asset.name}</div>
                      <div className="text-sm text-muted-foreground">
                        {transfer.transferType} • {formatTokenAmount(transfer.amount.toString())} tokens
                      </div>
                    </div>
                    <div className="text-right">
                      <div className={`text-sm font-medium ${
                        transfer.status === 'COMPLETED' ? 'text-green-600' :
                        transfer.status === 'FAILED' ? 'text-red-600' :
                        'text-yellow-600'
                      }`}>
                        {transfer.status}
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {new Date(transfer.createdAt).toLocaleDateString()}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
