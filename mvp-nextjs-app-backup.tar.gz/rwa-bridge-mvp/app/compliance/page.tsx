import { prisma } from '@/lib/db'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { formatDateTime, getStatusColor } from '@/lib/utils'
import { getKYCStatusLabel, getAccreditationLabel } from '@/lib/compliance'
import { Shield, CheckCircle2, AlertCircle } from 'lucide-react'

export const dynamic = 'force-dynamic'

export default async function CompliancePage() {
  const demoUser = await prisma.user.findUnique({
    where: { email: 'demo@rwabridge.io' },
    include: {
      complianceRecords: {
        orderBy: { createdAt: 'desc' },
      },
    },
  })

  if (!demoUser) {
    return <div>User not found</div>
  }

  return (
    <div className="container mx-auto px-4 py-8 space-y-8">
      <div>
        <h1 className="text-4xl font-bold">Compliance</h1>
        <p className="text-muted-foreground mt-2">
          Your KYC/AML status and regulatory compliance
        </p>
      </div>

      {/* Compliance Status Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Shield className="h-4 w-4" />
              KYC Status
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2">
              {demoUser.kycStatus === 'VERIFIED' ? (
                <>
                  <CheckCircle2 className="h-5 w-5 text-green-600" />
                  <span className="text-lg font-semibold text-green-600">Verified</span>
                </>
              ) : (
                <>
                  <AlertCircle className="h-5 w-5 text-yellow-600" />
                  <span className="text-lg font-semibold text-yellow-600">
                    {getKYCStatusLabel(demoUser.kycStatus)}
                  </span>
                </>
              )}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Shield className="h-4 w-4" />
              Accreditation
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-lg font-semibold">
              {getAccreditationLabel(demoUser.accreditationStatus)}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Investor classification
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Shield className="h-4 w-4" />
              Jurisdiction
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-lg font-semibold">{demoUser.jurisdiction}</div>
            <p className="text-xs text-muted-foreground mt-1">
              Primary jurisdiction
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Compliance Records */}
      <Card>
        <CardHeader>
          <CardTitle>Compliance Records</CardTitle>
          <CardDescription>
            Your verification history and compliance documentation
          </CardDescription>
        </CardHeader>
        <CardContent>
          {demoUser.complianceRecords.length === 0 ? (
            <p className="text-muted-foreground text-center py-8">No compliance records found</p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Type</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Verified By</TableHead>
                  <TableHead>Verified Date</TableHead>
                  <TableHead>Expires</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {demoUser.complianceRecords.map((record) => (
                  <TableRow key={record.id}>
                    <TableCell className="font-medium">
                      {record.recordType.replace('_', ' ')}
                    </TableCell>
                    <TableCell>
                      <Badge className={getStatusColor(record.status)}>
                        {record.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {record.verifiedBy || 'N/A'}
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {record.verifiedAt ? formatDateTime(record.verifiedAt) : 'N/A'}
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {record.expiresAt ? formatDateTime(record.expiresAt) : 'Never'}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* Compliance Information */}
      <Card>
        <CardHeader>
          <CardTitle>Regulatory Information</CardTitle>
          <CardDescription>
            Important compliance and regulatory details
          </CardDescription>
        </CardHeader>
        <CardContent className="prose prose-sm max-w-none">
          <p className="text-sm text-muted-foreground">
            <strong>Accredited Investor Status:</strong> Required for investments over $100,000 per asset.
            Verified through financial statements, income verification, or professional credentials.
          </p>
          <p className="text-sm text-muted-foreground mt-4">
            <strong>KYC/AML Compliance:</strong> All investors must complete KYC verification before participating.
            Documents are reviewed within 3-5 business days.
          </p>
          <p className="text-sm text-muted-foreground mt-4">
            <strong>Regulatory Framework:</strong> This platform operates under SEC Regulation D (506(c)) for US
            investors and complies with relevant international securities regulations.
          </p>
        </CardContent>
      </Card>
    </div>
  )
}
