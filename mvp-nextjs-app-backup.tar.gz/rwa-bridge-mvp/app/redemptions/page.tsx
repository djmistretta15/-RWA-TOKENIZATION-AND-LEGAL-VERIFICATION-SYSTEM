import { prisma } from '@/lib/db'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { formatTokenAmount, formatDateTime, getStatusColor } from '@/lib/utils'

export const dynamic = 'force-dynamic'

export default async function RedemptionsPage() {
  const demoUser = await prisma.user.findUnique({
    where: { email: 'demo@rwabridge.io' },
  })

  if (!demoUser) {
    return <div>User not found</div>
  }

  const redemptions = await prisma.redemptionRequest.findMany({
    where: { userId: demoUser.id },
    include: {
      asset: true,
    },
    orderBy: { createdAt: 'desc' },
  })

  return (
    <div className="container mx-auto px-4 py-8 space-y-8">
      <div>
        <h1 className="text-4xl font-bold">Redemptions</h1>
        <p className="text-muted-foreground mt-2">
          Request and track asset redemptions
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Redemption Requests</CardTitle>
          <CardDescription>
            All your redemption requests and their status
          </CardDescription>
        </CardHeader>
        <CardContent>
          {redemptions.length === 0 ? (
            <p className="text-muted-foreground text-center py-8">No redemption requests yet</p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Asset</TableHead>
                  <TableHead>Amount</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Legal Proof</TableHead>
                  <TableHead>Requested</TableHead>
                  <TableHead>Updated</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {redemptions.map((redemption) => (
                  <TableRow key={redemption.id}>
                    <TableCell>
                      <div className="font-medium">{redemption.asset.name}</div>
                      <div className="text-sm text-muted-foreground">{redemption.asset.tokenSymbol}</div>
                    </TableCell>
                    <TableCell>{formatTokenAmount(redemption.amount.toString())}</TableCell>
                    <TableCell>
                      <Badge className={getStatusColor(redemption.status)}>
                        {redemption.status}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      {redemption.legalProofHash ? (
                        <span className="text-green-600 text-sm">✓ Provided</span>
                      ) : (
                        <span className="text-muted-foreground text-sm">Pending</span>
                      )}
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {formatDateTime(redemption.createdAt)}
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {formatDateTime(redemption.updatedAt)}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
