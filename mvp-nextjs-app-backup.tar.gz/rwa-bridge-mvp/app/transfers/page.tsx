import { prisma } from '@/lib/db'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { formatTokenAmount, formatDateTime, truncateAddress, getStatusColor } from '@/lib/utils'

export const dynamic = 'force-dynamic'

export default async function TransfersPage() {
  const demoUser = await prisma.user.findUnique({
    where: { email: 'demo@rwabridge.io' },
  })

  if (!demoUser) {
    return <div>User not found</div>
  }

  const transfers = await prisma.transfer.findMany({
    where: { fromUserId: demoUser.id },
    include: {
      asset: true,
    },
    orderBy: { createdAt: 'desc' },
  })

  return (
    <div className="container mx-auto px-4 py-8 space-y-8">
      <div>
        <h1 className="text-4xl font-bold">Transfers</h1>
        <p className="text-muted-foreground mt-2">
          View your token transfer history
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Transfer History</CardTitle>
          <CardDescription>
            All token transfers initiated by you
          </CardDescription>
        </CardHeader>
        <CardContent>
          {transfers.length === 0 ? (
            <p className="text-muted-foreground text-center py-8">No transfers yet</p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Asset</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Amount</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>TX Hash</TableHead>
                  <TableHead>Date</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {transfers.map((transfer) => (
                  <TableRow key={transfer.id}>
                    <TableCell>
                      <div className="font-medium">{transfer.asset.name}</div>
                      <div className="text-sm text-muted-foreground">{transfer.asset.tokenSymbol}</div>
                    </TableCell>
                    <TableCell>{transfer.transferType}</TableCell>
                    <TableCell>{formatTokenAmount(transfer.amount.toString())}</TableCell>
                    <TableCell>
                      <Badge className={getStatusColor(transfer.status)}>
                        {transfer.status}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <span className="font-mono text-xs">
                        {transfer.transactionHash ? truncateAddress(transfer.transactionHash) : 'Pending'}
                      </span>
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {formatDateTime(transfer.createdAt)}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
