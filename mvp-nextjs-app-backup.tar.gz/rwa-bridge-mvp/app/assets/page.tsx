import { prisma } from '@/lib/db'
import { AssetCard } from '@/components/asset-card'
import { Button } from '@/components/ui/button'
import { Plus } from 'lucide-react'

export const dynamic = 'force-dynamic'

export default async function AssetsPage() {
  const demoUser = await prisma.user.findUnique({
    where: { email: 'demo@rwabridge.io' },
  })

  if (!demoUser) {
    return <div>User not found</div>
  }

  // Get all assets with user ownership info
  const allAssets = await prisma.asset.findMany({
    include: {
      ownerships: {
        where: { userId: demoUser.id },
      },
    },
    orderBy: { createdAt: 'desc' },
  })

  const userAssets = allAssets.filter(asset => asset.ownerships.length > 0)
  const availableAssets = allAssets.filter(asset => asset.ownerships.length === 0 && asset.status === 'ACTIVE')

  return (
    <div className="container mx-auto px-4 py-8 space-y-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-4xl font-bold">Assets</h1>
          <p className="text-muted-foreground mt-2">
            Browse and manage tokenized real-world assets
          </p>
        </div>
        <Button>
          <Plus className="mr-2 h-4 w-4" />
          Register Asset
        </Button>
      </div>

      {/* Your Assets */}
      <div className="space-y-4">
        <div>
          <h2 className="text-2xl font-bold">Your Holdings</h2>
          <p className="text-muted-foreground">
            Assets you currently own tokens for
          </p>
        </div>

        {userAssets.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground">
            You don't own any assets yet
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {userAssets.map((asset) => (
              <AssetCard
                key={asset.id}
                id={asset.id}
                name={asset.name}
                tokenSymbol={asset.tokenSymbol}
                assetType={asset.assetType}
                status={asset.status}
                totalValue={asset.totalValue.toString()}
                userBalance={asset.ownerships[0]?.balance.toString()}
                jurisdiction={asset.jurisdiction}
                oracleConsensus={asset.oracleConsensus}
              />
            ))}
          </div>
        )}
      </div>

      {/* Available Assets */}
      <div className="space-y-4">
        <div>
          <h2 className="text-2xl font-bold">Available Assets</h2>
          <p className="text-muted-foreground">
            Explore assets available for investment
          </p>
        </div>

        {availableAssets.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground">
            No assets currently available
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {availableAssets.map((asset) => (
              <AssetCard
                key={asset.id}
                id={asset.id}
                name={asset.name}
                tokenSymbol={asset.tokenSymbol}
                assetType={asset.assetType}
                status={asset.status}
                totalValue={asset.totalValue.toString()}
                jurisdiction={asset.jurisdiction}
                oracleConsensus={asset.oracleConsensus}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
