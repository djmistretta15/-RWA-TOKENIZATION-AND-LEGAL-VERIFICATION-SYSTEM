import { notFound } from 'next/navigation'
import { prisma } from '@/lib/db'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { formatCurrency, formatTokenAmount, formatDateTime, truncateAddress, getAssetTypeColor, getStatusColor } from '@/lib/utils'
import { Building2, FileText, Shield, TrendingUp, ExternalLink } from 'lucide-react'

export const dynamic = 'force-dynamic'

export default async function AssetDetailPage({ params }: { params: { id: string } }) {
  const asset = await prisma.asset.findUnique({
    where: { id: params.id },
    include: {
      ownerships: {
        include: {
          user: true,
        },
      },
      legalDocuments: true,
      transfers: {
        orderBy: { createdAt: 'desc' },
        take: 10,
      },
    },
  })

  if (!asset) {
    notFound()
  }

  const demoUser = await prisma.user.findUnique({
    where: { email: 'demo@rwabridge.io' },
  })

  const userOwnership = asset.ownerships.find(o => o.userId === demoUser?.id)

  return (
    <div className="container mx-auto px-4 py-8 space-y-8">
      {/* Header */}
      <div className="space-y-4">
        <div className="flex items-start justify-between">
          <div>
            <h1 className="text-4xl font-bold">{asset.name}</h1>
            <p className="text-muted-foreground mt-2">{asset.description}</p>
          </div>
          {userOwnership && (
            <Button>Request Redemption</Button>
          )}
        </div>

        <div className="flex gap-2">
          <Badge className={getAssetTypeColor(asset.assetType)}>
            {asset.assetType.replace('_', ' ')}
          </Badge>
          <Badge className={getStatusColor(asset.status)}>
            {asset.status}
          </Badge>
          {asset.oracleConsensus && (
            <Badge className="bg-blue-100 text-blue-800">
              Oracle Verified ✓
            </Badge>
          )}
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total Value
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(asset.totalValue.toString())}</div>
            {asset.oraclePrice && (
              <p className="text-xs text-muted-foreground mt-1">
                Oracle: {formatCurrency(asset.oraclePrice.toString())}
              </p>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total Supply
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatTokenAmount(asset.totalSupply.toString())}</div>
            <p className="text-xs text-muted-foreground mt-1">tokens</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Token Symbol
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold font-mono">{asset.tokenSymbol}</div>
            <p className="text-xs text-muted-foreground mt-1">{asset.partitionType}</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Your Holdings
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-primary">
              {userOwnership ? formatTokenAmount(userOwnership.balance.toString()) : '0'}
            </div>
            <p className="text-xs text-muted-foreground mt-1">tokens</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Legal Information */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Shield className="h-5 w-5" />
              Legal Information
            </CardTitle>
            <CardDescription>Legal wrapper and compliance details</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <div className="text-sm font-medium">Legal Wrapper</div>
              <div className="text-muted-foreground">{asset.legalWrapperType}</div>
            </div>
            <div>
              <div className="text-sm font-medium">Jurisdiction</div>
              <div className="text-muted-foreground">{asset.jurisdiction}</div>
            </div>
            <div>
              <div className="text-sm font-medium">Legal Entity ID</div>
              <div className="text-muted-foreground font-mono text-sm">
                {asset.legalEntityId || 'N/A'}
              </div>
            </div>
            <div>
              <div className="text-sm font-medium">Document Hash</div>
              <div className="text-muted-foreground font-mono text-xs break-all">
                {truncateAddress(asset.documentHash, 12)}
              </div>
            </div>
            <div>
              <div className="text-sm font-medium">Geo-Stamp</div>
              <div className="text-muted-foreground">{asset.geoStamp}</div>
            </div>
          </CardContent>
        </Card>

        {/* Blockchain Information */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Building2 className="h-5 w-5" />
              Blockchain Details
            </CardTitle>
            <CardDescription>On-chain contract information</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <div className="text-sm font-medium">Contract Address</div>
              {asset.contractAddress ? (
                <div className="flex items-center gap-2 text-muted-foreground font-mono text-sm">
                  {truncateAddress(asset.contractAddress)}
                  <ExternalLink className="h-3 w-3" />
                </div>
              ) : (
                <div className="text-muted-foreground">Not deployed yet</div>
              )}
            </div>
            <div>
              <div className="text-sm font-medium">Last Oracle Update</div>
              <div className="text-muted-foreground">
                {asset.lastOracleUpdate ? formatDateTime(asset.lastOracleUpdate) : 'Never'}
              </div>
            </div>
            <div>
              <div className="text-sm font-medium">Oracle Consensus</div>
              <div className="text-muted-foreground">
                {asset.oracleConsensus ? '✓ Reached (2/3)' : '✗ Not reached'}
              </div>
            </div>
            <div>
              <div className="text-sm font-medium">Notary Signature</div>
              <div className="text-muted-foreground font-mono text-xs break-all">
                {truncateAddress(asset.notarySignature, 12)}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Legal Documents */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            Legal Documents
          </CardTitle>
          <CardDescription>
            Court-admissible documentation stored on IPFS/Arweave
          </CardDescription>
        </CardHeader>
        <CardContent>
          {asset.legalDocuments.length === 0 ? (
            <p className="text-sm text-muted-foreground">No documents uploaded yet</p>
          ) : (
            <div className="space-y-3">
              {asset.legalDocuments.map((doc) => (
                <div key={doc.id} className="flex items-center justify-between py-2 border-b last:border-0">
                  <div>
                    <div className="font-medium">{doc.documentType}</div>
                    <div className="text-xs text-muted-foreground">
                      {formatDateTime(doc.uploadedAt)}
                    </div>
                  </div>
                  <div className="flex gap-2">
                    {doc.ipfsUrl && (
                      <Button variant="outline" size="sm">
                        IPFS <ExternalLink className="ml-1 h-3 w-3" />
                      </Button>
                    )}
                    {doc.arweaveUrl && (
                      <Button variant="outline" size="sm">
                        Arweave <ExternalLink className="ml-1 h-3 w-3" />
                      </Button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Recent Transfers */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5" />
            Recent Transfers
          </CardTitle>
          <CardDescription>Latest token movements for this asset</CardDescription>
        </CardHeader>
        <CardContent>
          {asset.transfers.length === 0 ? (
            <p className="text-sm text-muted-foreground">No transfers yet</p>
          ) : (
            <div className="space-y-3">
              {asset.transfers.slice(0, 5).map((transfer) => (
                <div key={transfer.id} className="flex items-center justify-between py-2 border-b last:border-0">
                  <div>
                    <div className="font-medium">{transfer.transferType}</div>
                    <div className="text-sm text-muted-foreground">
                      {formatTokenAmount(transfer.amount.toString())} tokens
                    </div>
                  </div>
                  <div className="text-right">
                    <Badge className={getStatusColor(transfer.status)}>
                      {transfer.status}
                    </Badge>
                    <div className="text-xs text-muted-foreground mt-1">
                      {formatDateTime(transfer.createdAt)}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
