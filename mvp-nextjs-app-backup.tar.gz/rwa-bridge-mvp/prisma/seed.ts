import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

async function main() {
  console.log('🌱 Starting database seed...')

  // Create Users
  const demoUser = await prisma.user.upsert({
    where: { email: 'demo@rwabridge.io' },
    update: {},
    create: {
      email: 'demo@rwabridge.io',
      name: 'Demo Investor',
      role: 'INVESTOR',
      kycStatus: 'VERIFIED',
      accreditationStatus: 'ACCREDITED_INVESTOR',
      walletAddress: '0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb7',
      jurisdiction: 'US',
    },
  })

  const admin = await prisma.user.upsert({
    where: { email: 'admin@rwabridge.io' },
    update: {},
    create: {
      email: 'admin@rwabridge.io',
      name: 'Admin User',
      role: 'ADMIN',
      kycStatus: 'VERIFIED',
      accreditationStatus: 'INSTITUTIONAL',
      walletAddress: '0x892d13889c4a9d7c3e3e3e3e3e3e3e3e3e3e3e3e',
      jurisdiction: 'US',
    },
  })

  const investor2 = await prisma.user.upsert({
    where: { email: 'investor2@rwabridge.io' },
    update: {},
    create: {
      email: 'investor2@rwabridge.io',
      name: 'Jane Smith',
      role: 'INVESTOR',
      kycStatus: 'VERIFIED',
      accreditationStatus: 'QUALIFIED_PURCHASER',
      walletAddress: '0x123d35Cc6634C0532925a3b844Bc9e7595f0bEb8',
      jurisdiction: 'UK',
    },
  })

  const investor3 = await prisma.user.upsert({
    where: { email: 'investor3@rwabridge.io' },
    update: {},
    create: {
      email: 'investor3@rwabridge.io',
      name: 'Robert Chen',
      role: 'INVESTOR',
      kycStatus: 'PENDING',
      accreditationStatus: 'NOT_ACCREDITED',
      jurisdiction: 'SINGAPORE',
    },
  })

  console.log('✅ Created users')

  // Create Assets
  const manhattanRE = await prisma.asset.upsert({
    where: { tokenSymbol: 'MAN-RE-001' },
    update: {},
    create: {
      name: 'Manhattan Luxury Apartment Complex',
      description: 'Prime real estate in Manhattan, NY. 50-unit luxury apartment building with commercial space on ground floor.',
      assetType: 'REAL_ESTATE',
      jurisdiction: 'DELAWARE',
      totalValue: 15000000.00,
      tokenSymbol: 'MAN-RE-001',
      totalSupply: 15000.00,
      partitionType: 'common',
      status: 'ACTIVE',
      contractAddress: '0xA1b2C3d4E5f6789012345678901234567890aBcD',
      documentHash: '0x' + Buffer.from('manhattan-deed-hash').toString('hex').padEnd(64, '0'),
      notarySignature: '0x' + Buffer.from('notary-sig-manhattan').toString('hex').padEnd(130, '0'),
      geoStamp: '40.7580,-73.9855',
      legalWrapperType: 'Delaware LLC',
      legalEntityId: 'DE-LLC-2023-001',
      lastOracleUpdate: new Date(),
      oraclePrice: 15250000.00,
      oracleConsensus: true,
    },
  })

  const techPE = await prisma.asset.upsert({
    where: { tokenSymbol: 'TECH-PE-001' },
    update: {},
    create: {
      name: 'TechVentures Growth Fund III',
      description: 'Private equity fund focused on late-stage tech companies. Portfolio includes 12 companies across SaaS, AI, and fintech.',
      assetType: 'PRIVATE_EQUITY',
      jurisdiction: 'CAYMAN',
      totalValue: 50000000.00,
      tokenSymbol: 'TECH-PE-001',
      totalSupply: 50000.00,
      partitionType: 'preferred',
      status: 'ACTIVE',
      contractAddress: '0xB2c3D4e5F67890123456789012345678901bCdEf',
      documentHash: '0x' + Buffer.from('techventures-fund-hash').toString('hex').padEnd(64, '0'),
      notarySignature: '0x' + Buffer.from('notary-sig-techventures').toString('hex').padEnd(130, '0'),
      geoStamp: '19.3133,-81.2546',
      legalWrapperType: 'Cayman Islands Exempted Company',
      legalEntityId: 'KY-EC-2023-002',
      lastOracleUpdate: new Date(Date.now() - 3600000),
      oraclePrice: 52300000.00,
      oracleConsensus: true,
    },
  })

  const corpBond = await prisma.asset.upsert({
    where: { tokenSymbol: 'CORP-BND-001' },
    update: {},
    create: {
      name: 'AAA Corporate Bond Series 2024',
      description: 'Investment-grade corporate bonds from Fortune 500 companies. 5-year maturity, 4.5% coupon rate.',
      assetType: 'BOND',
      jurisdiction: 'DELAWARE',
      totalValue: 10000000.00,
      tokenSymbol: 'CORP-BND-001',
      totalSupply: 10000.00,
      partitionType: 'common',
      status: 'ACTIVE',
      contractAddress: '0xC3d4E5f6789012345678901234567890cDeFa123',
      documentHash: '0x' + Buffer.from('corp-bond-indenture').toString('hex').padEnd(64, '0'),
      notarySignature: '0x' + Buffer.from('notary-sig-corpbond').toString('hex').padEnd(130, '0'),
      geoStamp: '39.7392,-104.9903',
      legalWrapperType: 'Delaware Statutory Trust',
      legalEntityId: 'DE-DST-2024-003',
      lastOracleUpdate: new Date(Date.now() - 7200000),
      oraclePrice: 10050000.00,
      oracleConsensus: true,
    },
  })

  const artCollection = await prisma.asset.upsert({
    where: { tokenSymbol: 'ART-COL-001' },
    update: {},
    create: {
      name: 'Contemporary Art Collection - Blue Chip',
      description: 'Curated collection of 25 contemporary artworks from established artists. Includes pieces by Banksy, Hirst, and Koons.',
      assetType: 'ART',
      jurisdiction: 'SWISS',
      totalValue: 8000000.00,
      tokenSymbol: 'ART-COL-001',
      totalSupply: 8000.00,
      partitionType: 'common',
      status: 'PENDING',
      documentHash: '0x' + Buffer.from('art-collection-provenance').toString('hex').padEnd(64, '0'),
      notarySignature: '0x' + Buffer.from('notary-sig-art').toString('hex').padEnd(130, '0'),
      geoStamp: '47.3769,8.5417',
      legalWrapperType: 'Swiss Foundation',
      legalEntityId: 'CH-FDN-2024-004',
      lastOracleUpdate: new Date(Date.now() - 86400000),
      oraclePrice: 8200000.00,
      oracleConsensus: false,
    },
  })

  const londonRE = await prisma.asset.upsert({
    where: { tokenSymbol: 'LON-RE-001' },
    update: {},
    create: {
      name: 'London Commercial Office Building',
      description: 'Grade A office space in Canary Wharf. 15-story building with long-term institutional tenants.',
      assetType: 'REAL_ESTATE',
      jurisdiction: 'UK',
      totalValue: 25000000.00,
      tokenSymbol: 'LON-RE-001',
      totalSupply: 25000.00,
      partitionType: 'common',
      status: 'ACTIVE',
      contractAddress: '0xD4e5F6789012345678901234567890dEfAb1234',
      documentHash: '0x' + Buffer.from('london-property-deed').toString('hex').padEnd(64, '0'),
      notarySignature: '0x' + Buffer.from('notary-sig-london').toString('hex').padEnd(130, '0'),
      geoStamp: '51.5074,-0.1278',
      legalWrapperType: 'UK Limited Partnership',
      legalEntityId: 'UK-LP-2023-005',
      lastOracleUpdate: new Date(Date.now() - 1800000),
      oraclePrice: 25500000.00,
      oracleConsensus: true,
    },
  })

  console.log('✅ Created assets')

  // Create Asset Ownerships
  await prisma.assetOwnership.createMany({
    data: [
      {
        assetId: manhattanRE.id,
        userId: demoUser.id,
        balance: 5000.00,
        partition: 'common',
        lastSyncBlock: 18500000,
      },
      {
        assetId: manhattanRE.id,
        userId: investor2.id,
        balance: 7500.00,
        partition: 'common',
        lastSyncBlock: 18500000,
      },
      {
        assetId: manhattanRE.id,
        userId: admin.id,
        balance: 2500.00,
        partition: 'common',
        lastSyncBlock: 18500000,
      },
      {
        assetId: techPE.id,
        userId: demoUser.id,
        balance: 10000.00,
        partition: 'preferred',
        lastSyncBlock: 18501000,
      },
      {
        assetId: techPE.id,
        userId: investor2.id,
        balance: 25000.00,
        partition: 'preferred',
        lastSyncBlock: 18501000,
      },
      {
        assetId: corpBond.id,
        userId: demoUser.id,
        balance: 3000.00,
        partition: 'common',
        lastSyncBlock: 18502000,
      },
      {
        assetId: londonRE.id,
        userId: investor2.id,
        balance: 15000.00,
        partition: 'common',
        lastSyncBlock: 18503000,
      },
    ],
    skipDuplicates: true,
  })

  console.log('✅ Created asset ownerships')

  // Create Transfers
  await prisma.transfer.createMany({
    data: [
      {
        assetId: manhattanRE.id,
        fromUserId: admin.id,
        amount: 2500.00,
        partition: 'common',
        transferType: 'PURCHASE',
        status: 'COMPLETED',
        complianceCheck: true,
        transactionHash: '0x' + Buffer.from('tx-hash-1').toString('hex').padEnd(64, '0'),
        blockNumber: 18500000,
        executedAt: new Date(Date.now() - 7 * 24 * 3600000),
      },
      {
        assetId: techPE.id,
        fromUserId: demoUser.id,
        amount: 5000.00,
        partition: 'preferred',
        transferType: 'PURCHASE',
        status: 'COMPLETED',
        complianceCheck: true,
        transactionHash: '0x' + Buffer.from('tx-hash-2').toString('hex').padEnd(64, '0'),
        blockNumber: 18501000,
        executedAt: new Date(Date.now() - 5 * 24 * 3600000),
      },
      {
        assetId: corpBond.id,
        fromUserId: demoUser.id,
        amount: 1500.00,
        partition: 'common',
        transferType: 'PURCHASE',
        status: 'PENDING',
        complianceCheck: true,
        executedAt: new Date(Date.now() - 2 * 3600000),
      },
      {
        assetId: manhattanRE.id,
        fromUserId: investor2.id,
        amount: 1000.00,
        partition: 'common',
        transferType: 'SALE',
        status: 'FAILED',
        complianceCheck: false,
        failureReason: 'KYC verification expired',
        executedAt: new Date(Date.now() - 24 * 3600000),
      },
    ],
    skipDuplicates: true,
  })

  console.log('✅ Created transfers')

  // Create Redemption Requests
  await prisma.redemptionRequest.createMany({
    data: [
      {
        assetId: manhattanRE.id,
        userId: demoUser.id,
        amount: 1000.00,
        status: 'PENDING',
      },
      {
        assetId: techPE.id,
        userId: investor2.id,
        amount: 5000.00,
        status: 'APPROVED',
        legalProofHash: '0x' + Buffer.from('legal-proof-redemption-1').toString('hex').padEnd(64, '0'),
        notarySignature: '0x' + Buffer.from('notary-redemption-sig').toString('hex').padEnd(130, '0'),
        approvedBy: admin.id,
        approvedAt: new Date(Date.now() - 24 * 3600000),
      },
      {
        assetId: corpBond.id,
        userId: demoUser.id,
        amount: 500.00,
        status: 'REJECTED',
        rejectionReason: 'Insufficient documentation provided',
        updatedAt: new Date(Date.now() - 3 * 24 * 3600000),
      },
    ],
    skipDuplicates: true,
  })

  console.log('✅ Created redemption requests')

  // Create Compliance Records
  await prisma.complianceRecord.createMany({
    data: [
      {
        userId: demoUser.id,
        recordType: 'KYC',
        status: 'APPROVED',
        verifiedBy: admin.id,
        verifiedAt: new Date(Date.now() - 30 * 24 * 3600000),
        expiresAt: new Date(Date.now() + 335 * 24 * 3600000), // ~1 year
        documentUrl: 'ipfs://Qm...kyc-demo-user',
      },
      {
        userId: demoUser.id,
        recordType: 'ACCREDITATION',
        status: 'APPROVED',
        verifiedBy: admin.id,
        verifiedAt: new Date(Date.now() - 60 * 24 * 3600000),
        expiresAt: new Date(Date.now() + 305 * 24 * 3600000),
        documentUrl: 'ipfs://Qm...accreditation-demo',
      },
      {
        userId: investor2.id,
        recordType: 'KYC',
        status: 'APPROVED',
        verifiedBy: admin.id,
        verifiedAt: new Date(Date.now() - 45 * 24 * 3600000),
        expiresAt: new Date(Date.now() + 320 * 24 * 3600000),
        documentUrl: 'ipfs://Qm...kyc-investor2',
      },
      {
        userId: investor3.id,
        recordType: 'KYC',
        status: 'PENDING',
        documentUrl: 'ipfs://Qm...kyc-investor3-pending',
      },
      {
        userId: demoUser.id,
        recordType: 'TAX_FILING',
        status: 'APPROVED',
        verifiedBy: admin.id,
        verifiedAt: new Date(Date.now() - 90 * 24 * 3600000),
        documentUrl: 'ipfs://Qm...tax-filing-2023',
        notes: 'W-8BEN form submitted and verified',
      },
    ],
    skipDuplicates: true,
  })

  console.log('✅ Created compliance records')

  // Create Legal Documents
  await prisma.legalDocument.createMany({
    data: [
      {
        assetId: manhattanRE.id,
        documentType: 'Operating Agreement',
        documentHash: '0x' + Buffer.from('op-agreement-manhattan').toString('hex').padEnd(64, '0'),
        ipfsUrl: 'ipfs://QmW2WQi7j6c7UgJTarActp7tDNikE4B2qXtFCfLPdsgaTQ',
        arweaveUrl: 'ar://abc123manhattan',
        uploadedBy: admin.id,
      },
      {
        assetId: manhattanRE.id,
        documentType: 'Asset Deed',
        documentHash: '0x' + Buffer.from('deed-manhattan').toString('hex').padEnd(64, '0'),
        ipfsUrl: 'ipfs://QmX3WQi7j6c7UgJTarActp7tDNikE4B2qXtFCfLPdsgaTR',
        arweaveUrl: 'ar://def456manhattan',
        uploadedBy: admin.id,
      },
      {
        assetId: manhattanRE.id,
        documentType: 'Appraisal Report',
        documentHash: '0x' + Buffer.from('appraisal-manhattan').toString('hex').padEnd(64, '0'),
        ipfsUrl: 'ipfs://QmY4WQi7j6c7UgJTarActp7tDNikE4B2qXtFCfLPdsgaTS',
        uploadedBy: admin.id,
      },
      {
        assetId: techPE.id,
        documentType: 'Fund Agreement',
        documentHash: '0x' + Buffer.from('fund-agreement-tech').toString('hex').padEnd(64, '0'),
        ipfsUrl: 'ipfs://QmZ5WQi7j6c7UgJTarActp7tDNikE4B2qXtFCfLPdsgaTT',
        arweaveUrl: 'ar://ghi789techpe',
        uploadedBy: admin.id,
      },
      {
        assetId: corpBond.id,
        documentType: 'Bond Indenture',
        documentHash: '0x' + Buffer.from('indenture-corpbond').toString('hex').padEnd(64, '0'),
        ipfsUrl: 'ipfs://QmA6WQi7j6c7UgJTarActp7tDNikE4B2qXtFCfLPdsgaTU',
        arweaveUrl: 'ar://jkl012corpbond',
        uploadedBy: admin.id,
      },
    ],
    skipDuplicates: true,
  })

  console.log('✅ Created legal documents')

  console.log('🎉 Database seed completed successfully!')
}

main()
  .then(async () => {
    await prisma.$disconnect()
  })
  .catch(async (e) => {
    console.error('❌ Seed error:', e)
    await prisma.$disconnect()
    process.exit(1)
  })
