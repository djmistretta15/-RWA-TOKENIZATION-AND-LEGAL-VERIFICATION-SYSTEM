import Link from 'next/link'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { formatCurrency, formatTokenAmount, getAssetTypeColor, getStatusColor } from '@/lib/utils'
import { ExternalLink } from 'lucide-react'

interface AssetCardProps {
  id: string
  name: string
  tokenSymbol: string
  assetType: string
  status: string
  totalValue: string | number
  userBalance?: string | number
  jurisdiction: string
  oracleConsensus: boolean
}

export function AssetCard({
  id,
  name,
  tokenSymbol,
  assetType,
  status,
  totalValue,
  userBalance,
  jurisdiction,
  oracleConsensus,
}: AssetCardProps) {
  return (
    <Link href={`/assets/${id}`}>
      <Card className="hover:shadow-md transition-shadow cursor-pointer h-full">
        <CardHeader>
          <div className="flex items-start justify-between">
            <div className="space-y-1">
              <CardTitle className="text-lg">{name}</CardTitle>
              <CardDescription className="flex items-center gap-2">
                <span className="font-mono text-xs">{tokenSymbol}</span>
                <span>•</span>
                <span>{jurisdiction}</span>
              </CardDescription>
            </div>
            <ExternalLink className="h-4 w-4 text-muted-foreground" />
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-2">
            <Badge className={getAssetTypeColor(assetType)}>
              {assetType.replace('_', ' ')}
            </Badge>
            <Badge className={getStatusColor(status)}>
              {status}
            </Badge>
            {oracleConsensus && (
              <Badge className="bg-blue-100 text-blue-800">
                Oracle ✓
              </Badge>
            )}
          </div>

          <div className="grid grid-cols-2 gap-4 pt-2">
            <div>
              <div className="text-sm text-muted-foreground">Total Value</div>
              <div className="text-lg font-semibold">{formatCurrency(totalValue)}</div>
            </div>
            {userBalance !== undefined && (
              <div>
                <div className="text-sm text-muted-foreground">Your Holdings</div>
                <div className="text-lg font-semibold text-primary">
                  {formatTokenAmount(userBalance)} tokens
                </div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </Link>
  )
}
