import Link from 'next/link'
import { Building2, Home, ArrowRightLeft, FileText, Shield } from 'lucide-react'

const navItems = [
  { name: 'Dashboard', href: '/', icon: Home },
  { name: 'Assets', href: '/assets', icon: Building2 },
  { name: 'Transfers', href: '/transfers', icon: ArrowRightLeft },
  { name: 'Redemptions', href: '/redemptions', icon: FileText },
  { name: 'Compliance', href: '/compliance', icon: Shield },
]

export function Nav() {
  return (
    <nav className="border-b bg-background">
      <div className="container mx-auto px-4">
        <div className="flex h-16 items-center justify-between">
          <div className="flex items-center space-x-8">
            <Link href="/" className="flex items-center space-x-2">
              <Building2 className="h-6 w-6 text-primary" />
              <span className="text-xl font-bold">RWA Bridge</span>
            </Link>

            <div className="hidden md:flex space-x-1">
              {navItems.map((item) => (
                <Link
                  key={item.name}
                  href={item.href}
                  className="flex items-center space-x-2 px-3 py-2 rounded-md text-sm font-medium text-muted-foreground hover:text-foreground hover:bg-accent transition-colors"
                >
                  <item.icon className="h-4 w-4" />
                  <span>{item.name}</span>
                </Link>
              ))}
            </div>
          </div>

          <div className="flex items-center space-x-4">
            <div className="text-sm">
              <div className="text-muted-foreground">Demo User</div>
              <div className="text-xs text-green-600">● Verified</div>
            </div>
          </div>
        </div>
      </div>
    </nav>
  )
}
