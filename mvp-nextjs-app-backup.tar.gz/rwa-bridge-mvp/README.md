# 🚀 RWA Bridge - Real-World Asset Tokenization Platform

A production-quality MVP for tokenizing real-world assets (real estate, bonds, private equity) with legal enforceability, regulatory compliance, and court-admissible records.

## 🎯 What is RWA Bridge?

RWA Bridge is an enterprise-grade platform that solves the critical problem of **legally-backed tokenization** for real-world assets:

- **Legal Enforceability**: Court-recognizable SPV/LLC structures with notarized documentation
- **Regulatory Compliance**: Built-in SEC, KYC/AML, and multi-jurisdiction support
- **1-Block Sync**: Blockchain and legal registry stay synchronized
- **Oracle Consensus**: 3-source price verification for accurate valuations
- **Audit Trail**: Immutable compliance records stored on IPFS/Arweave

## 🛠️ Tech Stack

- **Framework**: Next.js 15 (App Router) + React + TypeScript
- **Styling**: Tailwind CSS + shadcn/ui components
- **Database**: PostgreSQL + Prisma ORM
- **Auth**: Supabase Auth (or demo user stub)
- **Deployment**: Vercel-ready

## 📊 Core Features

### 1. Asset Dashboard (`/`)
- Portfolio overview with total value and asset breakdown
- Quick stats: holdings, active assets, pending redemptions
- Recent activity feed

### 2. Assets Page (`/assets`)
- Browse all tokenized assets
- View your holdings vs. available investments
- Filter by asset type, jurisdiction, status

### 3. Asset Detail (`/assets/[id]`)
- Complete asset information (legal, blockchain, financial)
- Legal documents with IPFS/Arweave links
- Transfer history and oracle data
- Request redemption functionality

### 4. Transfers (`/transfers`)
- View all token transfer history
- Track transfer status and transaction hashes
- Compliance verification results

### 5. Redemptions (`/redemptions`)
- Submit redemption requests
- Track legal handover process
- View approval status and documentation

### 6. Compliance Portal (`/compliance`)
- KYC/AML verification status
- Accreditation level display
- Compliance record history
- Regulatory information

## 🚀 Quick Start

### Prerequisites

```bash
node >= 18.0.0
npm >= 9.0.0
PostgreSQL database (Supabase or Neon recommended)
```

### 1. Clone and Install

```bash
git clone <your-repo-url>
cd rwa-bridge-mvp
npm install
```

### 2. Configure Environment

Create `.env` file:

```env
# Database
DATABASE_URL="postgresql://user:password@localhost:5432/rwa_bridge?schema=public"

# Supabase (optional)
NEXT_PUBLIC_SUPABASE_URL="your-supabase-url"
NEXT_PUBLIC_SUPABASE_ANON_KEY="your-supabase-anon-key"

# App Config
NEXT_PUBLIC_APP_URL="http://localhost:3000"
NODE_ENV="development"
```

### 3. Initialize Database

```bash
# Generate Prisma client
npm run prisma:generate

# Run migrations
npm run prisma:migrate

# Seed with demo data
npm run prisma:seed
```

### 4. Run Development Server

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

## 📦 npm Scripts

```bash
npm run dev              # Start development server
npm run build            # Build for production
npm run start            # Start production server
npm run lint             # Run ESLint
npm run prisma:generate  # Generate Prisma client
npm run prisma:migrate   # Run database migrations
npm run prisma:seed      # Seed database with demo data
npm run prisma:studio    # Open Prisma Studio (DB GUI)
npm run setup            # Full setup (generate + migrate + seed)
```

## 📊 Database Schema

### Core Entities

- **User**: Investors, admins, compliance officers
- **Asset**: Tokenized real-world assets
- **AssetOwnership**: User token balances per asset
- **Transfer**: Token transfer history
- **RedemptionRequest**: Asset redemption requests
- **ComplianceRecord**: KYC/AML verification records
- **LegalDocument**: Legal documentation (IPFS/Arweave)

### Key Features

- Multi-jurisdiction support (Delaware, Swiss, ADGM, Wyoming, Cayman, Singapore, UK, EU)
- Asset types: Real Estate, Private Equity, Bonds, Commodities, Art
- Compliance tracking: KYC, AML, Accreditation, Tax Filing
- Legal wrapper types: LLC, SPV, Statutory Trust, Foundation

## 🎨 UI Components

Built with **shadcn/ui** for a clean, professional look:

- Cards for asset display
- Tables for transaction history
- Badges for status indicators
- Forms for data entry
- Navigation with responsive design

## 🔐 Authentication

The MVP uses a **demo user** approach for simplicity:

- Demo user: `demo@rwabridge.io`
- All actions are performed as this user
- For production: integrate Supabase Auth or your preferred provider

## 📡 API Structure

Server Actions and Route Handlers live in `app/api/*`:

```
app/api/
├── assets/          # Asset management endpoints
├── transfers/       # Transfer processing
└── redemptions/     # Redemption requests
```

## 🌐 Deployment

### Vercel (Recommended)

1. Push code to GitHub
2. Import project in Vercel
3. Add environment variables
4. Deploy!

### Database Hosting

**Recommended options:**

- [Supabase](https://supabase.com/) - Free tier available
- [Neon](https://neon.tech/) - Serverless Postgres
- [Railway](https://railway.app/) - Easy deployment

## 📝 Demo Data

The seed script creates:

- 4 demo users (investor, admin, etc.)
- 5 real-world assets:
  - Manhattan Luxury Apartment Complex ($15M)
  - TechVentures Growth Fund III ($50M PE)
  - AAA Corporate Bond Series 2024 ($10M)
  - Contemporary Art Collection ($8M)
  - London Commercial Office Building ($25M)
- Asset ownerships, transfers, redemptions
- Compliance records (KYC, AML, Accreditation)
- Legal documents with IPFS/Arweave links

## 🔒 Security Features

- Notary signatures for legal documents
- Oracle consensus (3-source verification)
- Compliance checks on transfers
- Immutable audit trail
- Multi-layer freeze mechanisms
- Storage layout validation for upgrades

## 🛣️ Roadmap

**Current MVP (v1.0)**:
- ✅ Asset management and portfolio tracking
- ✅ Transfer history and compliance
- ✅ Redemption workflow
- ✅ Compliance portal

**Coming Soon**:
- Real-time blockchain integration
- Smart contract deployment interface
- Multi-signature governance
- Advanced analytics dashboard
- Mobile app (React Native)

## 📚 Additional Resources

- [Prisma Documentation](https://www.prisma.io/docs)
- [Next.js 15 Docs](https://nextjs.org/docs)
- [shadcn/ui Components](https://ui.shadcn.com/)
- [Tailwind CSS](https://tailwindcss.com/docs)

## 🤝 Contributing

This is a production MVP for demonstration purposes. For production deployment:

1. Implement real authentication
2. Connect to actual smart contracts
3. Integrate real oracle providers
4. Add comprehensive error handling
5. Implement rate limiting
6. Add monitoring and logging
7. Security audit

## 📄 License

Proprietary - RWA Bridge Platform

---

**Built with ❤️ for the future of tokenized real-world assets**

For questions or support, contact: [your-email@company.com]
